def setting(method):
    return {hello : (type(str), type(list))}

def hello(connect):
    print("hello sample1")

