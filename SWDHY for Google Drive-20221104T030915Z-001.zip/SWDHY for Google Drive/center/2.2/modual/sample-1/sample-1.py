def hello():
    print("hello sample1")

